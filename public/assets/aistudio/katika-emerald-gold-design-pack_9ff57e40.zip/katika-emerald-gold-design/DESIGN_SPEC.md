# Katika.Bet — UI Design Specification

## 1. Design principles
- Premium dark fintech aesthetic, not a conventional sportsbook.
- Clear hierarchy: market question first, probability and Yes/No prices second, context (volume/liquidity/expiry) third.
- Emerald communicates affirmative/action/probability; gold is a restrained accent for featured items and selected states.
- Use generous spacing, thin borders, subtle surface contrast, and readable typography.
- Keep the interface responsive and usable on narrow mobile screens.

## 2. Color tokens
| Token | Value | Usage |
|---|---|---|
| Background | `#080D12` | App background |
| Surface 1 | `#111A20` | Cards, panels |
| Surface 2 | `#19252B` | Inputs, hover, nested panels |
| Border | `#26343A` | Dividers and outlines |
| Emerald | `#00D69A` | Primary action, Yes, positive movement |
| Emerald dark | `#063E32` | Soft emerald fills |
| Gold | `#D9B45B` | Featured accents, premium highlights |
| Text | `#F4F7F5` | Primary text |
| Muted | `#8B999E` | Metadata and secondary text |
| Rose | `#E66D78` | No/negative movement |

## 3. Desktop layout
- Top navigation: brand at left, primary navigation in the middle, wallet/account actions at right.
- Main content uses a three-column composition where space allows:
  - Left: category navigation / discovery filters.
  - Center: market feed with featured market and market cards.
  - Right: compact trending/volume or portfolio context panel.
- Main content max width around 1440px; preserve comfortable gutters.
- On medium screens, collapse the right rail before compressing the market feed.

## 4. Mobile layout
- Compact top bar with logo and wallet/account action.
- Horizontally scrollable category chips.
- One-column market cards.
- Fixed bottom navigation with clear active state; leave bottom safe-area padding so content is not obscured.
- Trade interaction should use a bottom sheet or full-width modal, not a cramped side panel.

## 5. Market card anatomy
1. Category and optional featured marker.
2. Market question (strongest text element).
3. Optional thumbnail/illustration slot, if the project has a relevant asset.
4. Probability bar with Yes/No proportions.
5. Two action/quote areas: Yes (emerald) and No (rose).
6. Volume/liquidity and close/expiry metadata.
7. Optional trend/change indicator, only when backed by real data.

## 6. Components
- Buttons: primary emerald; secondary dark outlined; gold used sparingly.
- Chips: dark surface, thin border; active chip uses a soft emerald tint and emerald text.
- Cards: `Surface 1`, 14–18px radius, 1px border; hover lifts slightly on desktop only.
- Inputs: `Surface 2`, visible focus ring, labels always visible.
- Dialogs: clear title, market context, Yes/No selection, amount field, estimated outcome; never hide fees or transaction status if those are available.
- Empty states: calm and useful, with one clear action.
- Loading states: skeletons that preserve layout dimensions.

## 7. Interaction and accessibility
- All controls need keyboard focus styles.
- Do not use color alone to communicate Yes/No or selected states; include text labels.
- Ensure text contrast and touch targets (aim for 44px minimum).
- Respect reduced-motion preferences.
- Keep market actions disabled when required data or wallet state is unavailable; show an explanatory message.
- Preserve existing wallet/auth flow and devnet indicators. Do not replace real project behavior with demo interactions.

## 8. Responsive breakpoints
- Small mobile: up to 640px.
- Tablet: 641–1024px.
- Desktop: 1025px and above.
- At mobile width, hide desktop side rails and use the bottom navigation.
