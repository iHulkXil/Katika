# Katika.Bet — Emerald & Gold UI Design Pack

This is a design handoff pack for the Katika.Bet prediction-market interface. It is intentionally framework-light so another coding assistant can adapt it to the existing React + Vite + TypeScript + Tailwind application.

## Files
- `design-system.css` — reusable color, typography, spacing, surface, button, chip, and card styles.
- `market-dashboard.html` — responsive visual prototype with sample market cards and desktop/mobile layouts.
- `IMPLEMENTATION_PROMPT.md` — paste-ready instructions for the AI that will implement the design in the GitHub repository.
- `DESIGN_SPEC.md` — layout, component, responsive, and interaction requirements.

## Visual direction
Premium, restrained dark interface. Charcoal surfaces, emerald as the primary action/probability color, and muted gold for highlights. Avoid bright gradients, excessive glow, and casino-like visual noise.

## Important implementation note
The prototype contains illustrative market data only. Preserve the project's existing routes, authentication, wallet integration, market data model, transaction behavior, and other working features. Do not present sample values as live market data or imply real-money trading unless the product's existing backend supports it.
