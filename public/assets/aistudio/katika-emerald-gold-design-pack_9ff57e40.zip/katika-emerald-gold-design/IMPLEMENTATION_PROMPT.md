# Prompt for the coding AI with GitHub access

Implement the attached Katika.Bet Emerald & Gold design pack directly in the existing `iHulkXil/Katika` GitHub repository.

## First inspect; do not blindly replace
1. Inspect the current project structure, package scripts, routes, components, styles, and existing market/wallet/auth flows.
2. Identify the current market homepage component, app shell/navigation component, global stylesheet, and market detail/trade components.
3. Keep the existing framework and conventions (the project is React + Vite + TypeScript + Tailwind, with Wouter and Lucide in the current architecture unless the repository has since changed).
4. Create a feature branch before editing. Do not use Replit.

## Design target
Use `DESIGN_SPEC.md` and `design-system.css` as the source of truth. Apply the premium dark palette:
- background `#080D12`
- surfaces `#111A20` and `#19252B`
- emerald `#00D69A`
- gold `#D9B45B`
- text `#F4F7F5`
- muted `#8B999E`
- rose `#E66D78`

The result should feel like a polished prediction-market fintech product inspired by the clarity of Polymarket, but with its own Katika identity. Do not copy another site's branding.

## Required work
- Restyle the existing app shell and navigation.
- Restyle the markets home/feed and market cards.
- Make desktop responsive with a left discovery rail, central market feed, and optional right information rail where the existing app content supports it.
- Make mobile a deliberate one-column experience with horizontal category chips and bottom navigation.
- Use clear Yes/No prices, probability visualization, and market metadata only where those values already exist in the app data.
- Restyle existing trade/bet dialogs and forms without changing their business logic.
- Preserve existing market creation, filtering, positions/My Bets, profile, wallet, authentication, Privy integration, Solana devnet behavior, routes, and persistence.
- Reuse existing components and icons where practical. Avoid adding dependencies unless essential.
- Add accessible focus states, labels, keyboard behavior, and reduced-motion handling.

## Non-negotiable constraints
- Do not remove, stub, or fake working features.
- Do not invent live prices, liquidity, volume, charts, user balances, or transaction confirmations.
- Do not represent devnet activity as production or real-money trading.
- Do not change API contracts, database schemas, auth/session behavior, wallet signing, or transaction semantics as part of a visual redesign.
- Do not put secrets in the client.
- Do not delete existing routes or replace the app with the static HTML prototype.
- Keep the static prototype as a visual reference only.

## Verification
- Run the existing lint/typecheck/build scripts.
- Fix regressions introduced by the redesign.
- Test desktop and mobile layouts.
- Summarize changed files, preserved functionality, checks run, and any blockers.
- Commit changes to the feature branch and provide the branch/PR link; do not push directly to `main` unless explicitly requested.
